import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NoContentFoundComponent } from './core/components/no-content-found/no-content-found.component';
import { ProductDetailComponent } from './core/components/product-detail/product-detail.component';
import { ProductsViewComponent } from './core/components/products-view/products-view.component';
import { URLCanActivateService } from './core/services/url-canactivate.service';

const routes: Routes = [
  { path: '', redirectTo:'product-details', pathMatch:"full"},
  { path: 'product-details/:id',
   component: ProductDetailComponent,
  canActivate: [ URLCanActivateService]},
  { path: 'product-details', component: ProductDetailComponent },
  { path: 'product-view', component: ProductsViewComponent },
  { path: 'no-content-found', component: NoContentFoundComponent },

];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { 
  
}
