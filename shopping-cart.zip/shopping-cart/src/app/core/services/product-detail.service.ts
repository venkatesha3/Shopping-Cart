import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { ProductDetailsModel } from '../components/product-detail/product-detail.model';

@Injectable({
  providedIn: 'root'
})
export class ProductDetailService {

  private readonly productData:Array<ProductDetailsModel>;
  private readonly productData$:BehaviorSubject<Array<ProductDetailsModel>>;
    constructor() { 
      this.productData= new Array<ProductDetailsModel>();
      this.productData$ = new BehaviorSubject<Array<ProductDetailsModel>>(null);
    }
    setProductData(details){
      this.productData.push(details);
      this.productData$.next(this.productData);
    }
    editProductData(i,details:ProductDetailsModel){
      if(this.productData&&this.productData[i]){
        this.productData[i]={...details};
      }
      this.productData$.next(this.productData);
    }
    getProductData():Observable<Array<ProductDetailsModel>>{
      return  this.productData$.asObservable();
    }
    deleteProductData(i):Observable<Array<ProductDetailsModel>>{
      this.productData.splice(i,1);
      this.productData$.next(this.productData);
      return  this.productData$.asObservable();
    }
    getSelectedProduct(index):ProductDetailsModel{
      const selectedProduct= (this.productData&&this.productData.slice(index,index+1)[0])||null;
      return selectedProduct;
    }
}
