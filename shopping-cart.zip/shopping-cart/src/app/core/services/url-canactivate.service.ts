import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Resolve, Router, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable } from "rxjs";
import { ProductDetailService } from "./product-detail.service";
@Injectable({
  providedIn: 'root'
})

export class URLCanActivateService implements CanActivate {
  constructor(private router: Router, private productDetailService: ProductDetailService) {

  }
  canActivate(activatedroute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | boolean | UrlTree {
    const type = activatedroute.queryParamMap.get("type");
    if (type.toLowerCase() == "editproduct") {
      const data = this.productDetailService.getSelectedProduct(+activatedroute.paramMap.get("id"))
      if (!data) {
        return this.router.parseUrl('/no-content-found');
      } else {
        return true;
      }
    } else {
      return true;
    }
  }
}