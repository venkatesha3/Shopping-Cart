import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductDetailService } from '../../services/product-detail.service';
import { ProductDetailsModel } from '../product-detail/product-detail.model';

@Component({
  selector: 'app-products-view',
  templateUrl: './products-view.component.html',
  styleUrls: ['./products-view.component.scss']
})
export class ProductsViewComponent implements OnInit {

  productData: Array<ProductDetailsModel>;
  constructor(private productDetailService: ProductDetailService, private router: Router) { }

  ngOnInit(): void {

    this.getData();
  }
  goToProductCreation() {
    this.router.navigate(["product-details"]);
  }
 
  getData() {
    this.productDetailService.getProductData().subscribe(res => this.productData = res);
  }
 
  editProduct(i){
    this.router.navigate(["product-details",i],{ queryParams: { type: 'editproduct' }});
  }
deleteProduct(i){
  this.productDetailService.deleteProductData(i);
}
}
