import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-content-found',
  templateUrl: './no-content-found.component.html',
  styleUrls: ['./no-content-found.component.scss']
})
export class NoContentFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
