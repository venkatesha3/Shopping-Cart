import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductDetailService } from '../../services/product-detail.service';
import { ProductDetailsModel } from './product-detail.model';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss']
})
export class ProductDetailComponent implements OnInit {

  ProductDetailForm:FormGroup;
  submitted = false;
  id:string;
  type:string;
  constructor(private formBuilder: FormBuilder,
    private productDetailService:ProductDetailService,
    private router:Router,
    private activatedroute:ActivatedRoute) { }
  value4: string;
  qualification:FormArray;
  editForm:boolean;
  ngOnInit(): void {
    this.id=this.activatedroute.snapshot.paramMap.get("id");
    this.type=this.activatedroute.snapshot.queryParamMap.get("type");
    this.ProductDetailForm = new FormGroup({
    'name':new FormControl(null,[Validators.required]),
     'description':new FormControl(null,[Validators.required]),
     'price':new FormControl(null,[Validators.required]),
    });

    if(this.type?.toLowerCase()=="editproduct"){
      this.editForm=true;
      this.setproductDetails(this.productDetailService.getSelectedProduct(+this.id))
    }
  }
  setproductDetails(selectedProduct:ProductDetailsModel){
    
    this.ProductDetailForm.setValue({
        'name':selectedProduct?.name||"",
        'description':selectedProduct?.description||"",
        'price':selectedProduct?.price||""
    })
  }
  
  
    get f() { return this.ProductDetailForm.controls; }
  createItem(qulifaction):FormControl {
    return this.formBuilder.control(qulifaction)
  }
  navigateProductDetails(){
    this.router.navigate(["product-view"]);
  }
  onSubmit(){
    this.submitted = true;
    if (this.ProductDetailForm.invalid) {
      return;
  }
    const userData=this.ProductDetailForm.value as ProductDetailsModel;
    if(this.editForm){
      this.productDetailService.editProductData(this.id,userData);
    }else{
      this.productDetailService.setProductData(userData);
    }
   
    this.router.navigate(["product-view"]);
  }

}
