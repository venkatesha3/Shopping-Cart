export class ProductDetailsModel{
    name:string;
    description:string;
    price:string;
}