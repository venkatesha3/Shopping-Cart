import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms';
import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import { ProductDetailComponent } from './core/components/product-detail/product-detail.component';
import { ProductsViewComponent } from './core/components/products-view/products-view.component';
import { NoContentFoundComponent } from './core/components/no-content-found/no-content-found.component';


@NgModule({
  declarations: [
    AppComponent,
    ProductDetailComponent,
    ProductsViewComponent,
    NoContentFoundComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    TableModule,
    ButtonModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
